﻿//productos concretos, es lo que se va a poder usar en las fábricas concretas

namespace AFactory
{
    internal class Exams
    {
        //Exámenes
        public class PresencialExam : Exam
        {
            public void ShowExam()
            {
                System.Console.WriteLine("Examen Presencial");
            }
        }

        public class VirtualExam : Exam
        {
            public void ShowExam()
            {
                System.Console.WriteLine("Examen Virtual");
            }
        }
    }
}
