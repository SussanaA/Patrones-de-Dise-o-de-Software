﻿//Clase abstracta, fábrica (abstracta) de fábricas

namespace AFactory
{
    public interface Factory
    {
        Guide CreateGuide();
        Exam CreateExam();
    }
}
