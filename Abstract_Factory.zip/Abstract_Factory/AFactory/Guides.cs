﻿//productos concretos, es lo que se va a poder usar en las fábricas concretas

namespace AFactory
{
    internal class Guides
    {
        //Guías
        public class PresencialGuide : Guide
        {
            public void ShowGuide()
            {
                System.Console.WriteLine("Guía Presencial");
            }
        }

        public class VirtualGuide : Guide
        {
            public void ShowGuide()
            {
                System.Console.WriteLine("Guía Virtual");
            }
        }
    }
}
