﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AFactory
{
    //guías en ambos modos
    public class HibridoGuide : Guide
    {
        public override void ShowGuide()
        {
            System.Console.WriteLine("Guía en línea y guía impresa.");
        }
    }

    //examenes modo virtual y presencial
    public class HibridoExam : Exam
    {
        public override void ApplyExam()
        {
            System.Console.WriteLine("Examen en línea y examen impreso.");
        }
    }
}

