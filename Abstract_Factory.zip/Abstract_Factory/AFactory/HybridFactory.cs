﻿using System.Threading.Tasks;
using static AFactory.VirtualGuide;
using static AFactory.PresencialGuide;

//fábrica concreta
// modo en el que se puede tomar clase

namespace AFactory
{
    public class HybridFactory : Factory
    {
        public override Guide CreateGuide()
        {
            return new HibridoGuide();
        }

        public override Exam CreateExam()
        {
            return new HibridoExam();
        }
    }
}
