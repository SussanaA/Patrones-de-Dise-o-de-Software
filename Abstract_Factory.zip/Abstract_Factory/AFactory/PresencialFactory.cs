﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static AFactory.VirtualGuide;
using static AFactory.PresencialGuide;

//fábrica concreta
// modo en el que se puede tomar clase

namespace AFactory
{
    //modo presencial 
    public class PresencialFactory : Factory 
    {
        public override Guide CreateGuide()
        {
            return new PresencialGuide();
        }

        public override Exam CreateExam()
        {
            return new PresencialExam();
        }
    }
}
