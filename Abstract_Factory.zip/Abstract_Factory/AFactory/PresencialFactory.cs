﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static AFactory.Exams;
using static AFactory.Guides;

namespace AFactory
{
    public class PresencialFactory : Factory
    {
        public Guide CreateGuide()
        {
            return new PresencialGuide();
        }

        public Exam CreateExam()
        {
            return new PresencialExam();
        }
    }
}
