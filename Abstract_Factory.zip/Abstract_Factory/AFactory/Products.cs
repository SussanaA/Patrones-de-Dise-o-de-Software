﻿//productos abstractos, lo que va a poder generar cada producto concreto

namespace AFactory
{
    public interface Exam
    {
        void ShowExam();
    }

    public interface Guide
    {
        void ShowGuide();
    }
}
