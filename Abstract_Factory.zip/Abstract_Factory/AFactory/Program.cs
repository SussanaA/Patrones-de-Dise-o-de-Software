﻿//Cliente
using AFactory;
using System;

namespace Abstract_Factory
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //nombre de la clase abstracta
            Factory fabrica;


            //crea el material presencial
            fabrica = new PresencialFactory();

            //llama a que se creen las instancias
            Guide guia = fabrica.CreateGuide();
            Exam exam = fabrica.CreateExam();

            //crea los productos
            guia.ShowGuide();
            exam.ApplyExam();

            Console.WriteLine("---------------\n");


            //crea el material virtual
            fabrica = new VirtualFactory();

            //llama a las instancias
            guia = fabrica.CreateGuide();
            exam = fabrica.CreateExam();

            //crea los productos
            guia.ShowGuide();
            exam.ApplyExam();

            Console.WriteLine("----------------\n");


            //crea el material semipresencial
            fabrica = new HybridFactory();

            //llama a las instancias
            guia = fabrica.CreateGuide();
            exam = fabrica.CreateExam();

            //crea los productos
            guia.ShowGuide();
            exam.ApplyExam();

            Console.WriteLine("---------------------------------");

            Console.ReadKey();
        }
    }
}
