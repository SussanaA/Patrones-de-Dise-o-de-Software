﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static AFactory.Exams;
using static AFactory.Guides;

namespace AFactory
{
    internal class VirtualFactory : Factory
    {
        public Guide CreateGuide()
        {
            return new VirtualGuide();
        }

        public Exam CreateExam()
        {
            return new VirtualExam();
        }
    }
}
