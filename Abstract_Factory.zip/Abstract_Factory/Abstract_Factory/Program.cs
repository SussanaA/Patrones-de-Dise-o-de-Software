﻿//Cliente

using System;
using System.Security.Cryptography.X509Certificates;

namespace Abstract_Factory
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /////Menú
            //variable para la elección de la opción
            int op;

            //Switch para las diferentes opciones
            do
            {
                op = Opciones();
                switch (op)
                {
                    case 1:
                        modo(new PresencialFactory());
                        break;
                }

            }while(op != 4);

        }

        public static void modo()
        {

        }


        //método que contiene las opciones
        public static int Opciones()
        {
            Console.WriteLine("Modalidad de clase",
                "1- Modalidad presencial",
                "2- Modalidad en línea",
                "3- Modalidad Híbrida",
                "4- Cerrar",
                "Seleccione una opción: "
             );

            int lee = int.Parse(Console.ReadLine());
            return lee;
        }
    }
}
