﻿namespace Prototipo
{
    public class AccoPrototype : ExamPrototype
    {
        public override ExamPrototype Clone()
        {
            return (AccoPrototype)this.MemberwiseClone();
        }

        public override string VerExamen()
        {
            return $"Examen de Contabilidad\n" +
                $"Tipo de examen: {_examen_type}\n" +
                $"Clave de la materia: {_subject_code}\n" +
                $"Unidad: {_unit} \n" +
                $"Horario: {_horario}\n" +
                $"Salón: {_classroom}\n" +
                $"Docente: {_teacher}\n" +
                $"Estudiante: {_student}\n" +
                $"No. Control: {_id_Student}\n";
        }
    }
}
