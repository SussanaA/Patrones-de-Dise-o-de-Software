﻿using System;

namespace Prototipo
{
    public abstract class ExamPrototype
    {
        //atributos
        protected string _examen_type;
        protected string _subject_code;
        protected string _unit;
        protected string _horario;
        protected string _classroom;
        protected string _teacher;
        protected string _student;
        protected string _id_Student;

        //para acceso a los datos
        public string Examen_type { set => _examen_type = value; }
        public string Subject_code { set => _subject_code = value; }
        public string Unit { set => _unit = value; }
        public string Hora { set  => _horario = value; }
        public string Classroom { set  => _classroom = value; }
        public string Teacher { set => _teacher = value; }
        public string Student { set => _student = value; }
        public string Id_Student { set  => _id_Student = value; }

        //métodos
        public abstract ExamPrototype Clone();
        public abstract String VerExamen();
    }
}
