﻿namespace Prototipo
{
    public class InvPrototype : ExamPrototype
    {
        public override ExamPrototype Clone()
        {
            return (InvPrototype)this.MemberwiseClone();
        }

        public override string VerExamen()
        {
            return $"Examen de Taller de Investigación\n" +
                $"Tipo de examen: {_examen_type}\n" +
                $"Clave de la materia: {_subject_code}\n" +
                $"Unidad: {_unit} \n" +
                $"Horario: {_horario}\n" +
                $"Salón: {_classroom}\n" +
                $"Docente: {_teacher}\n" +
                $"Estudiante: {_student}\n" +
                $"No. Control: {_id_Student}";
        }
    }
}
