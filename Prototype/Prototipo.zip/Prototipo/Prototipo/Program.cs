﻿using System;

namespace Prototipo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            ExamPrototype diferencial = new DiferencialPrototype();
            ExamPrototype integral = new IntegralProtoype();
            ExamPrototype contabilidad = new AccoPrototype();
            ExamPrototype ing_soft = new ISPrototype();
            ExamPrototype mate = new MathPrototype();
            ExamPrototype redes = new RedesPrototype();
            ExamPrototype simulacion = new SimPrototype();
            ExamPrototype taller = new InvPrototype();


            ExamPrototype Aritmetica = mate.Clone();
            Aritmetica.Examen_type = "Presencial";
            Aritmetica.Subject_code = "ART-1";
            Aritmetica.Unit = "1";
            Aritmetica.Hora = "3-4";
            Aritmetica.Classroom = "9";
            Aritmetica.Teacher = "Gabriela Ramos";
            Aritmetica.Student = "Jorge Lopez";
            Aritmetica.Id_Student = "101010";
            Console.WriteLine(Aritmetica.VerExamen());

            ExamPrototype Tipos = redes.Clone();
            Tipos.Examen_type = "Virtual";
            Tipos.Subject_code = "ALB-2";
            Tipos.Unit = "2";
            Tipos.Hora = "4-5";
            Tipos.Classroom = "3";
            Tipos.Teacher = "abriela Ramos";
            Tipos.Student = "América Gómez";
            Tipos.Id_Student = "141415";
            Console.WriteLine(Tipos.VerExamen());

            Console.ReadKey();
        }
    }
}
