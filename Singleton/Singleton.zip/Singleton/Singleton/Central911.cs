﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//solo para la instancia
namespace Singleton
{
    //accesibilidad desde cualquier parte
    public class Central911
    {
        //guarda la única instancia de la clase
        private static Central911 _instance;

        //crea un objeto que despues de asignarse no puede modificarse (readonly)
        //evita que se creen más instancias
        private static readonly object _lock = new object(); 
         
        //variable que permite leer un valor y el otro solo puede ser modificado por la clase
        public string Central { get ; private set;}

        //constructor privado
        private Central911()
        {
            Central = "Central 911"; //nombre de la instancia (a donde se esta comunicando)
        }

        //metodo que devuelve la instancia
        public static Central911 GetInstance()
        {
            //verifica si no existe la instancia
            if (_instance == null)
            {
                //bloquea la creación de más instancias
                lock (_lock)
                {
                    //doble verificacion de que no exista la instancia
                    if (_instance == null)
                    {
                        //si no existe la crea
                        _instance = new Central911();
                    }
                }
            }
            //regresa la instancia, ya sea recien creada o la que ya estaba
            return _instance;
        }

        //método que conecta a una llamada con parametros de operador y tipo de emergencia
        public void ConnectCall(Operator operador, string EmergencyType)
        {
            //se muestra el nombre del operador que está atendiendo
            Console.WriteLine("\nLlamada conectada con el operador: " + operador.Operator_Name);
            //Muestra el tipo de emergencia
            operador.EmergencyResponder(EmergencyType);
        }
    }
}
