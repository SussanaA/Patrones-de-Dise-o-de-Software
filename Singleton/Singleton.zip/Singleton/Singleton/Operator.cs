﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Singleton
{
    //define publica la clase
    public class Operator
    {
        //variable para guardar los datos del operador
        public int Id_Operator { get; set; } //guarda el identificador
        public string Operator_Name { get; set; } //guarda el nombre del operador


        //constructor
        public Operator(int id, string name)
        {
            Id_Operator = id; //identificador del operador
            Operator_Name = name; //nombre del operador
        }

        //método que contiene los tipos de emergencia o situaciones
        public void EmergencyResponder(string EmergencyType)
        {
            //menciona quién atiende y de qué tipo de emergencia se trata
            Console.WriteLine($"Operador {Operator_Name} atendiendo emergencia del tipo: {EmergencyType}");

            //distintos casos para los tipos de emergencia
            switch (EmergencyType)
            {
                case "Intento de suicidio":
                    Console.WriteLine("Enviando unidades de apoyo y rescate.");
                    break;

                case "Incendio":
                    Console.WriteLine("Enviando bomberos.");
                    break;

                case "Accidente":
                    Console.WriteLine("Enviando paramédicos y oficiales.");
                    break;

                case "Violeta":
                    Console.WriteLine("Enviando unidad de policia violeta.");
                    break;
                case "Robo":
                    Console.WriteLine("Enviando unidad de policia para investigación");
                    break;
                default:
                    Console.WriteLine("Tipo de emergencia no reconocido.");
                    break;
            }
        }
    }
}

