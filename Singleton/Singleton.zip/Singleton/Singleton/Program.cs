﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Singleton
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //random para elegir indice de lista y asignar un operador a la llamada
            Random rnd = new Random();

            //se crean la llamadas que hace uso de la instancia
            Central911 Llamada = Central911.GetInstance();

            //se crea una lista y se guardan los operadores
            List<Operator> operators = new List<Operator>
            {
                new Operator(1, "Gerardo"), 
                new Operator(2, "Carlos"),
                new Operator(3, "Laura"),
                new Operator(4, "Felicia"),
                new Operator(5, "Bruno"),
                new Operator(6, "Esteban"),
                new Operator(7, "Rocio"),
                new Operator(8, "María")
            };

            //Lista para las emergencias
            List<String> emergency = new List<string>
            {
                "Violeta",
                "Intento de suicidio",
                "Incendio",
                "Accidente",
                "Robo"
            };

            //simulación de varias llamadas 
            //el indice del operador se selecciona de manera random desde la cantidad de operadores existentes
            //y se asigna de manera aleatoria una situación 
            for (int i = 0; i < 5; i++)
            {
                Llamada.ConnectCall(operators[rnd.Next(operators.Count)], emergency[rnd.Next(emergency.Count)]);
                Console.WriteLine(Llamada.GetHashCode()); //muestra el identificaor del objeto 
            }

            Console.ReadKey();
        }
    }
}
